package address;
import db_connection.ExecSQL;
import db_connection.Parameters;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Address {
	
    private String city_table, address_table, city_geo, query1, query2,
            key_attr, geo_attribute, city_str, address_pk, dbName;
    
    private Parameters p;
    
    public Address(
    		String TABLE, 
    		String ADDR_TABLE, 
    		String CITY_GEO,
            String QUERY1, 
            String QUERY2, 
            String KA, 
            String GEO_ATTR,
            String CITY_STR, 
            String ADDRESS_PK, 
            Parameters P, 
            String db) {
    	
        this.city_table = TABLE;
        this.city_geo = CITY_GEO;
        this.address_table = ADDR_TABLE;
        this.query1 = QUERY1;
        this.query2 = QUERY2;
        this.key_attr = KA;
        this.geo_attribute = GEO_ATTR;
        this.city_str = CITY_STR;
        this.address_pk = ADDRESS_PK;
        this.p = P;
        this.dbName = db;
        
        ExecSQL e0 = new ExecSQL(this.dbName, p);
        
        String sql = "";
        
        if (KA.equals("c_custkey")) {
        	
        	// Customer.
        	
            sql = "CREATE TABLE c_address (c_custkey int, c_address_pk int, city_name varchar(10));";
            e0.executeNonQuery(sql);
            sql = "SELECT AddGeometryColumn('c_address', 'c_address_geo', -1, 'POINT', 2 );";
            e0.executeNonQuery(sql);
            e0.disconnect();
            
        }
        
        if (KA.equals("s_suppkey")) {
        	
        	// Supplier.
        	
            sql = "CREATE TABLE s_address (s_suppkey int, s_address_pk int, city_name varchar(10));";
            e0.executeNonQuery(sql);
            sql = "SELECT AddGeometryColumn('s_address', 's_address_geo', -1, 'POINT', 2 );";
            e0.executeNonQuery(sql);
            e0.disconnect();
            
        }
        
    }
    
    public void createAddresses() {
    	
        double xMin=0, yMin=0, xMax=0, yMax=0, deltaX=0, deltaY=0;
        double x=0, y=0;
        
        //varrer todas as geometrias:        
        ExecSQL e1 = new ExecSQL(this.dbName, p);
        ResultSet r1, r2, r4;
        String city_name="", sql="";
        int j, keyvalue=-1;
        
        //outras consultas:
        ExecSQL e2 = new ExecSQL(this.dbName, p);
        
        //insercao
        ExecSQL e3 = new ExecSQL(this.dbName, p);
        
        //encontrar a chave correta
        ExecSQL e4 = new ExecSQL(this.dbName, p);
        
        int dumb=0;
        
        try {
        	
        	// Selects cities and the number of customers/suppliers in each.
        	
            r1 = e1.executeQuery(this.query1);
            
            // Run the loop for each city.
            
            while (r1.next()) {
            	
            	// Get number of customers/suppliers in the city and the city's name.
            	
                j = r1.getInt("count");
                city_name = r1.getString(this.city_str);
                
                // Selects every customer/supplier located in the city.
                
                r4 = e4.executeQuery(this.query2 + "'"+ city_name + "'");
                
                // Get the minimum X value of the city geometry's.
                
                r2 = e2.executeQuery("select st_xmin("+ this.city_geo + ") from " + this.city_table + " where city_name='" + city_name+"'");
                if (r2.next()) xMin = r2.getDouble("st_xmin");
                
                // Get the minimum Y value of the city geometry's.
                
                r2 = e2.executeQuery("select st_ymin("+ this.city_geo + ") from " + this.city_table + " where city_name='" + city_name+"'");
                if (r2.next()) yMin = r2.getDouble("st_ymin");
                
                // Get the maximum X value of the city geometry's.
                
                r2 = e2.executeQuery("select st_xmax("+ this.city_geo + ") from " + this.city_table + " where city_name='" + city_name+"'");
                if (r2.next()) xMax = r2.getDouble("st_xmax");
                
                // Get the maximum Y value of the city geometry's.
                
                r2 = e2.executeQuery("select st_ymax("+ this.city_geo + ") from " + this.city_table + " where city_name='" + city_name+"'");
                if (r2.next()) yMax = r2.getDouble("st_ymax");
                
                // Get the X and Y deltas.
                
                deltaX = xMax - xMin;   if (deltaX<0) deltaX = -deltaX;
                deltaY = yMax - yMin;   if (deltaY<0) deltaY = -deltaY;
                
                // Perform the following operations for every customer/supplier located in the city.
                
                int i=0;
                
                while ( (i<j) && (r4.next()) ) {
                	
                	// Keep generating points until one is contained in the city geometry.
                	
                    do{
                        
                    	// Get the customer/supplier key.
                    	
                    	keyvalue = r4.getInt(this.key_attr);
                        
                    	// Generate random coordinates for the customer/supplier address.
                    	
                        x = xMin + (Math.random()*deltaX);
                        y = yMin + (Math.random()*deltaY);
                        
                        // Check if the random point is within the city's geometry.
                        
                        sql = "select st_within(ST_GeometryFromText('POINT(" + String.valueOf(x) + " " + String.valueOf(y) + ")'), (select " + this.city_geo + " from " + this.city_table + " where city_name='" + city_name + "'))";
                        r2 = e2.executeQuery(sql);
                        r2.next();
                        
                    } while (!r2.getBoolean("st_within"));
                    
                    // Store the address in the customer/supplier addresses table.
                    
                    // The customer addresses table has four columns: customer primary key, 
                    // customer address primary key, city name and the address coordinates.
                    
                    // The supplier addresses table has four columns: supplier primary key,
                    // supplier address primary key, city name and the address coordinates.
                    
                    sql = "insert into " + this.address_table 
                        + " (" + this.geo_attribute + ", city_name, "
                        + this.key_attr + ", "  + this.address_pk
                        + ") values (ST_GeometryFromText('POINT("
                        + String.valueOf(x) + " " + String.valueOf(y)
                        + ")'), '" + city_name + "', " 
                        + String.valueOf(keyvalue) + ","  + String.valueOf(dumb)
                        + ")";
                    
                    e3.executeNonQuery(sql);
                    
                    // Log progress.
                    
                    dumb++;
                    if (dumb % 1000 == 0) System.out.println(dumb + " points for " + this.geo_attribute + " were created");
                    i++;
                    
                }   
                
            }
            
        } catch (SQLException ex){
        	
            ex.printStackTrace();
            
        }
        
        e1.disconnect(); e2.disconnect(); e3.disconnect(); e4.disconnect();
        
    }
    
}