package address;

import db_connection.Parameters;



public class Main {


    public static void main(String[] args) {

        /*Please, set your database parameters here*/
        String databaseClusterName = "colunar";
        Parameters p = new Parameters();
        p.setHost("localhost");
        p.setPasswd("password");
        p.setPort("5432");
        p.setUser("postgres");


        /*Please, do not modify the source code below*/
        String CITY_TABLE = "city"; //table with polygons
        String CITY_GEO = "city_geo"; //geometry column

        
        //CUSTOMER
        //how much customer addresses are there in each city?
        
        String QUERY1 = "select c_city, count (c_address) from customer group by c_city";
        String QUERY2 = "select c_custkey from customer where c_city = ";
        String ADDRESS_TABLE = "c_address"; //tabela onde armazenara' pontos
        String KEY_ATTR = "c_custkey"; //customer pk
        String GEO_ATTR = "c_address_geo";
        String CITY_STR = "c_city";
        String ADDRESS_PK = "c_address_pk";
        
        Address a = new Address(CITY_TABLE, ADDRESS_TABLE, CITY_GEO, QUERY1,
                QUERY2, KEY_ATTR, GEO_ATTR, CITY_STR, ADDRESS_PK, p, databaseClusterName);
        
        a.createAddresses();
 
   
              
        //SUPPLIER
        //how much supplier addresses are there in each city?
        
        QUERY1 = "select s_city, count (s_address) from supplier group by s_city";
        QUERY2 = "select s_suppkey from supplier where s_city = ";
        ADDRESS_TABLE = "s_address"; //table to store generated points
        KEY_ATTR = "s_suppkey";
        GEO_ATTR = "s_address_geo";
        CITY_STR = "s_city";
        ADDRESS_PK = "s_address_pk";
        
        a = new Address(CITY_TABLE, ADDRESS_TABLE, CITY_GEO, QUERY1, QUERY2,
                KEY_ATTR, GEO_ATTR, CITY_STR, ADDRESS_PK, p, databaseClusterName);
        a.createAddresses();
        
}

}