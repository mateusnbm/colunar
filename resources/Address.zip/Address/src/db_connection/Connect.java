package db_connection;

import java.sql.*;
import java.sql.Connection;



public class Connect {
    Connection conn;
    private boolean failed = false;
    
    /** Creates a new instance of Connect */
    public Connect(String dbName, Parameters p) {
        try{                        
                Class.forName("org.postgresql.Driver");
                String url = "jdbc:postgresql://" + p.getHost() + ":" 
                        + p.getPort() + "/" + dbName;
                conn = DriverManager.getConnection(url,p.getUser(),p.getPasswd());                
                 /* Add the geometry types to the connection. Note that you must
                  cast the connection to the pgsql-specific connection 
                  implementation before calling the addDataType() method.*/
                 ((org.postgresql.PGConnection)conn).addDataType("geometry", org.postgis.PGgeometry.class);                  
                // ((org.postgresql.PGConnection)conn).addDataType("box3d","org.postgis.PGbox3d");
                
        }catch(Exception e){
            this.failed = true;
            e.printStackTrace();
        }
    }    
    
    public boolean getFalhou (){
        return this.failed;
    }
    
}