package db_connection;

import java.sql.*;
import java.sql.Statement;



public class ExecSQL {
    private Connect c;
    public Statement stmt;    
    
    
        public ExecSQL(String dbName, Parameters p) {
        c = new Connect(dbName, p);
        try {
            this.stmt = this.c.conn.createStatement();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    //Execute SQL commands without retrieving results
    public void executeNonQuery(String sql){
        try {
            stmt.execute(sql);
        } catch (SQLException ex) {
            ex.printStackTrace();
            if (ex.getMessage().contains("integer out of range"))                
                System.out.println("ERROR: Integer out of range");
        }
        
    }


    //Execute SQL commands retrieving results
    public ResultSet executeQuery(String sql){
        try {
            return stmt.executeQuery(sql);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
     return null;   
    }


    public void disconnect(){
        try {
            this.stmt.close();
            this.c.conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    /* is dbName a PostgreSQL database cluster? */
    public boolean existsDB(String dbName){
        ResultSet r = this.executeQuery("select datname from pg_database where " +
                "datname = '" + dbName + "'");
        String s;
        try {
            if (r.next()){
                s = r.getString("datname");
                if (s.equals(dbName))
                    return true;
            }
        }catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }
        
}